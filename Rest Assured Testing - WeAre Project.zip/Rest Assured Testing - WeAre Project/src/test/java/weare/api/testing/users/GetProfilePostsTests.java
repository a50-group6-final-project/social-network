package weare.api.testing.users;

public class GetProfilePostsTests extends BaseUserSetup {


}
