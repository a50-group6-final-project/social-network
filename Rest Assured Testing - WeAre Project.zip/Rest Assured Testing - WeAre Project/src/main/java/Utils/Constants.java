package Utils;

public class Constants {

    public static final String APPLICATION_JSON = "application/json";


}
