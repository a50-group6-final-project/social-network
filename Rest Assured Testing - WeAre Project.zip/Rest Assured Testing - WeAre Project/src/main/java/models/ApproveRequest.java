package models;

public class ApproveRequest {


    private int id;
    private boolean approved;
    private boolean seen;
    private String timeStamp;
}
