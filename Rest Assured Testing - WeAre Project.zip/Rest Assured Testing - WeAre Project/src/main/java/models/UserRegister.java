package models;

public class UserRegister {

    public Category category;
    public String confirmPassword;
    public String email;
    public String password;
    public String username;
}
