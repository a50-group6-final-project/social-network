package models;

public class SearchUser {

        public int index;
        public boolean next;
        public String searchParam1;
        public String searchParam2;
        public int size;

}
