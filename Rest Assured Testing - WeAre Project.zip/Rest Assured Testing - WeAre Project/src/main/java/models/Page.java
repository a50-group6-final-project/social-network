package models;

public class Page {

    public int index;
    public boolean next = true;
    public String searchParam1 = "";
    public String searchParam2 = "";
    public int size;
}
