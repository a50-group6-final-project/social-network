package models;

public class SendRequest {


        public int id;
        public String username;
    }


