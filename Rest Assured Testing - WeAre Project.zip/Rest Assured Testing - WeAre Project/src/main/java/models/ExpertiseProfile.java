package models;

import java.util.ArrayList;

public class ExpertiseProfile {
    public int id;
    public ArrayList<Skill> skills;
    public Category category;
    public double availability;
}
