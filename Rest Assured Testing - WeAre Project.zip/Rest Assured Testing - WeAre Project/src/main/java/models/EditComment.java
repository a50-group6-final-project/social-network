package models;

public class EditComment {

}
