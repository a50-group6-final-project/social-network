package models;

public class Category {
    public int id;
    public String name;
}
