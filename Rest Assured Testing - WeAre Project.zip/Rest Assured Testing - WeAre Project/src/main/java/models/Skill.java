package models;


import java.util.Date;

public class Skill{
    public Category category;
    public String skill;
    public int skillId;
    public Object hibernateLazyInitializer;

}